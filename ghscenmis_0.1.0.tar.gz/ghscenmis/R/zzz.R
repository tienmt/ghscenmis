.onAttach <- function(libname, pkgname) {
  packageStartupMessage("There is C++ implementation in Github [[tienmt]] sothat it run much faster!")
}
